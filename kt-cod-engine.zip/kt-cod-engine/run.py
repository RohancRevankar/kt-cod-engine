"""One entry point:  python run.py <command>   (see README)"""
import sys
from src.cli import main
main(sys.argv[1:])
