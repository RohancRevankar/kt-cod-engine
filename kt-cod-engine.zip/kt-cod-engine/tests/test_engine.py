import sys, unittest
sys.path.insert(0, ".")
from src.engine import decide, load_cfg
from src.whatsapp import classify
from src import economics as eco

CFG = load_cfg()

class T(unittest.TestCase):
    def test_rto_cost(self):             # 65 + 65 + 25 + 0.08*180
        self.assertAlmostEqual(eco.rto_cost(CFG), 169.4)
    def test_breakeven_avg_order(self):  # ~70% at Rs649
        self.assertAlmostEqual(eco.breakeven_risk(649, CFG), 0.70, delta=0.01)
    def test_low_risk_ships(self):
        self.assertEqual(decide(0.10, 649, True, 0, CFG)[0], "ship_as_is")
    def test_mid_risk_nudges(self):
        self.assertEqual(decide(0.35, 649, True, 0, CFG)[0], "nudge_to_prepaid")
    def test_small_order_not_nudged(self):
        self.assertEqual(decide(0.35, 349, True, 0, CFG)[0], "ship_as_is")
    def test_high_risk_confirms(self):
        self.assertEqual(decide(0.60, 649, True, 0, CFG)[0], "ship_after_confirmation")
    def test_first_timer_protected_from_cancel(self):
        self.assertEqual(decide(0.85, 649, True, 0, CFG)[0], "ship_after_confirmation")
    def test_serial_returner_held(self):
        self.assertEqual(decide(0.30, 649, False, 2, CFG)[0], "hold_cancel")
    def test_never_cancel_profitable_big_basket(self):   # repeat customer, 80% risk, but Rs2,499 basket (break-even 90%)
        self.assertNotEqual(decide(0.80, 2499, False, 0, CFG)[0], "hold_cancel")
    def test_replies(self):
        self.assertEqual(classify("Haan!"), "yes"); self.assertEqual(classify("2"), "no")
        self.assertEqual(classify("kitna time lagega?"), "unclear")

if __name__ == "__main__": unittest.main()
