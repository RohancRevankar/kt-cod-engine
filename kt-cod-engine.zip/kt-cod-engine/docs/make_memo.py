from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import ParagraphStyle
from reportlab.lib.units import cm
from reportlab.lib import colors
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
D = "/usr/share/fonts/truetype/dejavu/"
pdfmetrics.registerFont(TTFont("F", D + "DejaVuSans.ttf")); pdfmetrics.registerFont(TTFont("FB", D + "DejaVuSans-Bold.ttf"))
pdfmetrics.registerFontFamily("F", normal="F", bold="FB")
B = ParagraphStyle("b", fontName="F", fontSize=8.4, leading=11.2, spaceAfter=3)
H = ParagraphStyle("h", fontName="FB", fontSize=10, leading=13, spaceBefore=6, spaceAfter=2, textColor=colors.HexColor("#1a3d7c"))
T = ParagraphStyle("t", fontName="FB", fontSize=13.5, leading=17)
L = ParagraphStyle("l", parent=B, leftIndent=9, bulletIndent=0, spaceAfter=2)
R = "₹"
def bl(t): return Paragraph(t, L, bulletText="•")
S = []
S.append(Paragraph("COD orders: stop the returns without stopping growth", T))
S.append(Paragraph("To: Founder &nbsp;|&nbsp; From: Rohan &nbsp;|&nbsp; 30 Oct 2026 &nbsp;|&nbsp; Numbers: 1,987 past COD orders; rules tested on September, which the model had never seen, scaled to ~1,650 COD orders a month.", B))
S.append(Paragraph("<b>Bottom line.</b> Returns cost us about <b>₹73,000 a month</b> on COD. Cancelling risky orders makes this worse, because a delivered order earns more than a return costs. Instead I recommend asking risky customers to confirm on WhatsApp or pay online for a small discount, and cancelling almost nothing. On September this would have added about <b>₹22,000 a month</b> (plausible range ₹1,000–₹25,000 until we test it live). I would run it as a two-week test before trusting that number.", B))
S.append(Paragraph("1. What surprised me in the data", H))
S.append(bl("<b>Cancelling is almost always the wrong call.</b> A return costs ₹169 (65 out, 65 back, 25 packing, 8% damaged at ₹180). A delivered average order earns ₹402 (62% of ₹649). So shipping still makes money until an order is about <b>70% likely to return</b>. I replayed September with the true outcomes: cancelling every order above 40% risk would have cancelled 19% of orders, 46% of them genuine, and cost <b>₹58,000 a month</b>. At 30% risk the loss is ₹102,000."))
S.append(bl("<b>Pincode blocking can’t work.</b> 1,987 orders landed in 1,066 different pincodes; only 30 have even 5 orders and none has 10. “Bad pincode history” is mostly noise. What does show is the <b>city</b>: Gorakhpur 62%, Bareilly 61%, Darbhanga 59%, Patna 48% return, against Mumbai and Pune at 18%. Bihar is 54%, Uttar Pradesh 44%, Maharashtra 18%."))
S.append(bl("<b>Junk addresses are the loud signal, Hinglish is not.</b> Addresses like “.”, “xyz”, “home”, “call me” (153 orders, 8%) return <b>64%</b> of the time, versus 23% for full addresses. Hinglish directions (“Hanuman Mandir ke saamne”) return 30%, but that is a small-city effect: inside big cities it is 21% vs 18%. Fake names (“Test Order”, “asdf”, “qwerty”) return 63%."))
S.append(bl("<b>First-time buyers are only mildly riskier; past returners are very risky.</b> First-timers return 30% vs 23% for repeat buyers, and they are 75% of our COD orders. A customer with one earlier return comes back 35%, with two earlier returns <b>76%</b>. Meta first-timers return 34% vs 22% for direct. Baskets over ₹1,800 return 41%, nearly double the ₹700–1,200 baskets (22%)."))
S.append(bl("<b>Data hygiene.</b> 30 duplicate orders, 4 spellings of the status, 17 invalid phone numbers, 3 zero-value orders. The sample’s average order is ₹920, not ₹649, so ₹ figures use real order values."))
S.append(Paragraph("2. Recommended rules and what they would have done to September", H))
rows = [["Rule (editable in config/rules.yaml)", "Orders / mo", "Share", "Actually returned", "Net ₹ / mo"],
        ["Risk under 25%: ship as-is", "1,038", "63%", "17%", "0"],
        ["25–50%: offer ₹30–90 off to pay online (5–12%, bigger for riskier)", "416", "25%", "31%", "+11,300"],
        ["50%+: ship only after WhatsApp confirmation", "176", "11%", "57%", "+10,800"],
        ["Hold/cancel: 90%+ first-time, 75%+ repeat, or 2 earlier returns", "20", "1%", "100%", "−200"],
        ["Total (saved 35,400 − lost 4,100 − discounts/WhatsApp 9,300)", "1,650", "", "", "+22,000"]]
t = Table([[Paragraph(str(c), B) for c in r] for r in rows], colWidths=[8.4*cm, 2.1*cm, 1.5*cm, 2.7*cm, 2.4*cm])
t.setStyle(TableStyle([("GRID", (0, 0), (-1, -1), 0.3, colors.grey), ("BACKGROUND", (0, 0), (-1, 0), colors.HexColor("#e8eefb")), ("BACKGROUND", (0, -1), (-1, -1), colors.HexColor("#f1f1ec")), ("VALIGN", (0, 0), (-1, -1), "MIDDLE"), ("TOPPADDING", (0, 0), (-1, -1), 1.5), ("BOTTOMPADDING", (0, 0), (-1, -1), 1.5)]))
S += [t, Spacer(1, 3)]
S.append(Paragraph("Cancelling is never allowed below the order’s own break-even risk (for a ₹2,499 basket that is 90%). <b>Prepaid discount maths</b> (₹649 order, 35% risk): offer ₹58 (9%). Someone who accepts swaps a ~28% return risk for the 4% prepaid rate, worth about ₹137 per acceptor in returns avoided and sales kept; the discount plus the 2% gateway fee costs ₹69. Net ₹68 per acceptor, and at an assumed 34% acceptance about ₹23 per order we message. A bigger discount buys little extra acceptance, so I scale it with risk and cap it at ₹90, about half of a ₹169 return.", B))
S.append(Paragraph("3. Operations vs Marketing, in rupees", H))
S.append(Paragraph("<b>Operations</b> asked for cancellation; the data says it loses money, but their goal is right: the leak is real and the rules plug about 30% of it (₹22,000 of ₹73,000) and put 53% of all returns into a bucket we act on. <b>Marketing</b> is right that a cancelled first order wastes the ₹300 ad spend: wrongly cancelling a genuine first-timer costs about ₹500 of margin and repeat value, plus the ₹300, against ₹169 saved per return. We would need roughly 5 true returns per mistake to break even, which only happens above ~75–90% risk. So in September only <b>1 of 241 first-time orders</b> would be cancelled (0.4%); 100 (42%) would get a WhatsApp message or a discount offer instead, and the cancel bar for new customers is set higher than for repeat ones. Marketing can change that bar by editing one number.", B))
S.append(Paragraph("4. What could go wrong, and how we would notice", H))
S.append(bl("<b>My customer-behaviour numbers are assumptions</b>: 60% reply to the confirmation, confirmed customers return half as often, 34% accept the discount. If confirmed customers return 80% as often as predicted, the confirmation bucket turns negative (−₹1,400/month). <i>Notice:</i> reply rate, and return rate per bucket on the dashboard weekly. Keep a random 10% of flagged orders shipping untouched so we measure the real effect."))
S.append(bl("<b>The score sorts, it doesn’t predict:</b> the top 20% riskiest orders hold 41% of all returns; 42% of returns still sit in the “ship as-is” group. Retrain monthly; alert if predicted and actual return rates drift apart by more than 5 points."))
S.append(bl("<b>Customer annoyance:</b> watch first-time conversion and WhatsApp “no reply” share; an AI misreading a real address as junk is caught by the confirmation step instead of a cancellation."))
S.append(Paragraph("5. What I’d build in two more weeks", H))
S.append(bl("Live test with a 10% holdout to replace every assumption above with a measured number. Real WhatsApp Business API, Shopify webhook and payment links."))
S.append(bl("Ask customers to fix junk or incomplete addresses and pincodes before shipping (saves both returns and cancellations), then courier choice by city and a call-the-customer step for failed deliveries."))
doc = SimpleDocTemplate("docs/business_memo.pdf", pagesize=A4, leftMargin=1.6*cm, rightMargin=1.6*cm, topMargin=1.3*cm, bottomMargin=1.2*cm, title="COD memo", author="Rohan")
doc.build(S)
