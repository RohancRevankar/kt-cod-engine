# COD order decision engine

Looks at every new COD order and picks one of four actions: **Ship as-is / Ship after confirmation / Nudge to prepaid / Hold-cancel**, each with a plain-English reason.

## Run it (under 5 minutes)

```bash
pip install -r requirements.txt          # pandas, numpy, scikit-learn, pyyaml, reportlab
python run.py all                        # backtest on September + builds out/dashboard.html
open out/dashboard.html                  # (or just double-click it)
python run.py whatsapp-demo              # 7 scripted chats: yes / no / random / silence, confirm + prepaid flows
python run.py chat                       # type as the customer; /wait 5h moves the clock, /pay simulates payment
python -m unittest tests.test_engine     # 10 tests
```

Other commands: `breakeven` (when is cancelling actually worth it), `discount` (the prepaid-discount maths), `sensitivity` (how wrong can my assumptions be), `findings` (every number in the memo), `score KT101753` (explain one order).

Optional: `export ANTHROPIC_API_KEY=...` makes the address/name check use an LLM (`src/llm.py`). Without it a regex fallback produces the same fields, so everything runs offline. **I could not test the live LLM path in my environment** - it is a thin, cached JSON call with fallback; the numbers in the memo come from the fallback.

## Change the rules without code
Edit **`config/rules.yaml`** (plain numbers, commented), save, run `python run.py backtest` to see what the new rules would have done to September. Cancel bars, confirm/nudge thresholds, discount tiers, WhatsApp timing and silence policy all live there. Money assumptions (clearly marked ASSUMPTION) live there too.

## How it works
```
orders_sample.csv -> cleaning.py (dupes, status spellings, phones)
  -> llm.py        LLM: is the address real/complete? is the name fake? (Hinglish ok)   [text understanding only]
  -> model.py      logistic regression -> chance the order returns  (explainable)         [maths]
  -> engine.py     risk + rules.yaml + break-even guard -> action + reason               [plain code]
  -> economics.py  Rs saved / lost / cost per action                                      [maths]
  -> whatsapp.py   state machine for the two customer-facing flows                        [code; LLM only for odd replies]
  -> dashboard.py  one-screen HTML
```
**Where I drew the LLM line:** LLM only where the input is messy human text (address quality, fake names, odd WhatsApp replies). History, geography, order value, the risk model, thresholds, discounts and every rupee calculation are code, because they are deterministic, auditable and free. See `docs/decision_log.md`.

## Honest limits
- Backtest = train Apr-Aug, replay September (329 orders, scaled x5 to 1,650 COD orders/month). Small sample.
- Savings from **confirm** and **nudge** depend on assumptions the data cannot verify (reply rate, how much confirmation cuts returns, prepaid acceptance). `python run.py sensitivity` shows the range. Only a live test with a holdout settles it.
- The sample's average order is Rs920, not the Rs649 in the brief; Rs figures use real order values.
