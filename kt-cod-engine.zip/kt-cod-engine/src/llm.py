"""
The LLM's ONE job: read the messy human text (name + address, English or Hinglish) and say
what kind of address it is and whether the name is fake.  Everything else (history, money,
thresholds, maths) is plain code - see docs/decision_log.md.

If ANTHROPIC_API_KEY is not set (or a call fails) we use the regex heuristic below, so the
project always runs.  Both return the SAME fields, so the rest of the system doesn't care.
"""
import json, os, re, urllib.request
import pandas as pd

MODEL = os.environ.get("JUDGE_MODEL", "claude-haiku-5-5")
CACHE = "out/llm_cache.json"
CLASSES = ["structured", "hinglish_landmark", "landmark_only", "junk"]

PROMPT = """You check delivery details for an Indian D2C shop. For each order decide:
address_class: one of
  structured        - has house/flat/sector number and a locality (real, deliverable)
  hinglish_landmark - Hinglish directions like "Station chowk se left, Hanuman Mandir ke saamne" (real but needs a call)
  landmark_only     - only 'near X' style, no house number
  junk              - placeholder or unusable ('.', 'xyz', 'home', 'call me', just a city name)
fake_name: true if the customer name is clearly fake ('asdf', 'test', 'xyz xyz', 'Test Order').
Reply with ONLY a JSON list, one object per order, in order:
[{"id": "...", "address_class": "...", "fake_name": false}]
Orders:
"""

def heuristic_address_class(a: str) -> str:
    a = (a or "").strip()
    if len(a) < 8 or a.lower() in {"home", "call me", "xyz", "na", "n/a"}:
        return "junk"
    if re.search(r"house|flat|sector|^[A-Za-z]-?\d|\d+/\d+", a, re.I) and re.search(r"\d", a):
        return "structured"
    if re.match(r"near ", a, re.I):
        return "landmark_only" if "ghar ka naam" not in a.lower() else "landmark_only"
    if re.search(r"ph krke|ke paas|ke saamne|peeche|se left|ke saath", a, re.I):
        return "hinglish_landmark"
    return "junk"

def heuristic_fake_name(n: str) -> bool:
    n = (n or "").strip().lower()
    return bool(re.search(r"\b(test|asdf|xyz|abc|dummy|fake|qwerty)\b", n)) or len(n) < 3 or bool(re.search(r"\d", n))

def _heuristic(df):
    return pd.DataFrame({
        "order_id": df["order_id"].values,
        "addr_class": df["address"].map(heuristic_address_class).values,
        "fake_name": df["customer_name"].map(heuristic_fake_name).values,
        "judge_source": "heuristic",
    })

def _call_llm(batch):
    body = {"model": MODEL, "max_tokens": 2000, "messages": [{"role": "user", "content":
            PROMPT + json.dumps([{"id": r.order_id, "name": r.customer_name, "address": r.address,
                                  "city": r.city} for r in batch.itertuples()])}]}
    req = urllib.request.Request("https://api.anthropic.com/v1/messages", json.dumps(body).encode(),
          {"content-type": "application/json", "x-api-key": os.environ["ANTHROPIC_API_KEY"],
           "anthropic-version": "2023-06-01"})
    text = json.load(urllib.request.urlopen(req, timeout=60))["content"][0]["text"]
    return json.loads(re.search(r"\[.*\]", text, re.S).group(0))

def judge(df, batch_size=40):
    """One row per order: addr_class, fake_name, judge_source ('llm' or 'heuristic')."""
    base = _heuristic(df)
    if not os.environ.get("ANTHROPIC_API_KEY"):
        return base
    cache = json.load(open(CACHE)) if os.path.exists(CACHE) else {}
    todo = df[~df["order_id"].isin(cache)]
    for i in range(0, len(todo), batch_size):
        try:
            for o in _call_llm(todo.iloc[i:i + batch_size]):
                if o.get("address_class") in CLASSES:
                    cache[o["id"]] = {"addr_class": o["address_class"], "fake_name": bool(o.get("fake_name"))}
        except Exception as e:                       # network/JSON problem -> heuristic fills the gap
            print("LLM batch failed, using heuristic:", e)
    os.makedirs("out", exist_ok=True); json.dump(cache, open(CACHE, "w"))
    for i, oid in base["order_id"].items():
        if oid in cache:
            base.loc[i, ["addr_class", "fake_name", "judge_source"]] = [cache[oid]["addr_class"], cache[oid]["fake_name"], "llm"]
    return base
