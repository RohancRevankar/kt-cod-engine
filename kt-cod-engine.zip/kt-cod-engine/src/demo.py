"""Scripted scenarios (python run.py whatsapp-demo) and an interactive chat (python run.py chat)."""
from datetime import datetime, timedelta
from .whatsapp import Conversation, render
from .engine import load_cfg

def _order(state="Uttar Pradesh", disc=52):
    return dict(order_id="KT101753", name="Meera Pillai", items="Satin Bonnet", value=649, city="Lucknow", state=state, discount=disc)

def scripted():
    cfg, t0 = load_cfg(), datetime(2026, 10, 30, 10, 0)
    scenarios = [("CONFIRM flow - customer says YES (Hinglish)", "confirm", "Uttar Pradesh", [("1h", "haan")]),
                 ("CONFIRM flow - customer says NO", "confirm", "Karnataka", [("30m", "2")]),
                 ("CONFIRM flow - random reply x3 -> human", "confirm", "Karnataka", [("10m", "kitna time lagega?"), ("20m", "???"), ("25m", "hello")]),
                 ("CONFIRM flow - silence for 24h -> cancel", "confirm", "Bihar", []),
                 ("NUDGE flow - customer pays", "nudge", "Delhi", [("2h", "haan pay karunga"), ("PAY", "")]),
                 ("NUDGE flow - customer declines -> ship as COD", "nudge", "Tamil Nadu", [("1h", "no")]),
                 ("NUDGE flow - silence 24h -> ship as COD", "nudge", "Maharashtra", [])]
    for title, flow, state, replies in scenarios:
        c = Conversation(_order(state), flow, cfg); c.start(t0)
        for delay, text in replies:
            if delay == "PAY": c.pay(t0 + timedelta(hours=2, minutes=5)); continue
            n = int(delay[:-1]); now = t0 + (timedelta(hours=n) if delay[-1] == "h" else timedelta(minutes=n))
            c.tick(now); c.reply(text, now)
        for h in range(1, 26): c.tick(t0 + timedelta(hours=h))       # let the clock run
        print(f"\n=== {title} ===\n{render(c)}\n>>> OUTCOME: {c.outcome or c.state}")

def interactive(order_id=None):
    cfg = load_cfg(); flow = input("Flow (confirm/nudge) [confirm]: ").strip() or "confirm"
    state = input("Customer state [Uttar Pradesh]: ").strip() or "Uttar Pradesh"
    c = Conversation(_order(state), flow, cfg); now = datetime(2026, 10, 30, 10, 0)
    print("\nType a customer reply, or  /wait 5h  to move the clock, /pay (simulate payment), or /quit\n"); print(f"BOT: {c.start(now)}")
    while c.state == "WAITING":
        s = input("> ").strip()
        if s == "/quit": break
        if s.startswith("/wait"):
            now += timedelta(hours=int(s.split()[1].rstrip("h"))); out = c.tick(now); print(f"[{now:%H:%M}] BOT: {out}" if out else f"[clock {now:%d %b %H:%M}]"); continue
        if s == "/pay": print("BOT:", c.pay(now)); continue
        print("BOT:", c.reply(s, now))
    print("OUTCOME:", c.outcome or c.state)
