"""Risk score = chance a COD order is returned. A plain logistic regression so every score can be explained."""
import numpy as np, pandas as pd
from sklearn.linear_model import LogisticRegression

UTMS = ["meta_ads", "google_ads", "influencer", "instagram_organic", "whatsapp_broadcast"]  # 'direct' = baseline
ADDRS = ["junk", "landmark_only", "hinglish_landmark"]                                      # 'structured' = baseline

def make_features(d, cities):
    X = pd.DataFrame(index=d.index)
    X["prior_rto_1"] = (d.customer_prior_rto == 1).astype(int)
    X["prior_rto_2plus"] = (d.customer_prior_rto >= 2).astype(int)
    X["repeat_customer"] = (d.customer_prior_orders > 0).astype(int)
    X["value_over_1800"] = (d.order_value > 1800).astype(int)
    X["value_under_700"] = (d.order_value <= 700).astype(int)
    X["fake_name"] = d.fake_name.astype(int)
    X["bad_phone"] = (~d.phone_valid).astype(int)
    for u in UTMS: X[f"utm_{u}"] = (d.utm_source == u).astype(int)
    for a in ADDRS: X[f"addr_{a}"] = (d.addr_class == a).astype(int)
    for c in cities: X[f"city_{c}"] = (d.city == c).astype(int)
    return X

# plain-English phrase for each feature, shown to ops when it pushes the risk up
PHRASE = {
    "prior_rto_1": "customer returned an earlier order", "prior_rto_2plus": "customer returned 2+ earlier orders",
    "value_over_1800": "large basket (over Rs1,800) - bigger orders get refused more", "fake_name": "name looks fake",
    "bad_phone": "phone number is not a valid 10-digit mobile", "addr_junk": "address is unusable",
    "addr_landmark_only": "address has no house number, only a landmark",
    "addr_hinglish_landmark": "address is directions only (Hinglish landmarks)", "utm_meta_ads": "came from Meta ads (higher returns)",
    "repeat_customer": "repeat customer", "value_under_700": "small basket",
}
GOOD = {"repeat_customer": "repeat customer with clean history", "addr_junk": None}

class RiskModel:
    def fit(self, d):
        self.cities = sorted(d.city.unique())
        self.base_rate = d.rto.mean()
        X = make_features(d, self.cities)
        self.cols = list(X.columns)
        self.lr = LogisticRegression(C=0.7, max_iter=2000).fit(X, d.rto)
        return self

    def predict(self, d):
        return self.lr.predict_proba(make_features(d, self.cities).reindex(columns=self.cols, fill_value=0))[:, 1]

    def reasons(self, row, top=3):
        """Return plain-English drivers of this order's risk, strongest first."""
        x = make_features(pd.DataFrame([row]), self.cities).reindex(columns=self.cols, fill_value=0).iloc[0]
        contrib = x.values * self.lr.coef_[0]
        out = []
        for i in np.argsort(-contrib):
            c = self.cols[i]
            if contrib[i] < 0.2 or len(out) >= top: break
            if c.startswith("city_"):
                out.append(f"{c[5:]} has high returns (area risk)")
            elif c in PHRASE: out.append(PHRASE[c])
        if not out:
            neg = [self.cols[i] for i in np.argsort(contrib) if contrib[i] < -0.2]
            out = [GOOD.get(c) or "city has low returns" if c.startswith("city_") else GOOD.get(c, "") for c in neg[:2]]
            out = [o for o in out if o] or ["no risk signals found"]
        return out
