import os, sys, json, copy
import pandas as pd
from . import economics as eco
from .backtest import prepare, split_run, summarize, monthly_cod
from .engine import load_cfg, LABEL
from .model import RiskModel

def rs(x): return f"Rs{x:,.0f}"

def cmd_backtest():
    cfg = load_cfg(); d, rep = prepare(); m, out, tr, te = split_run(cfg, d)
    g, real, tot, scale = summarize(out, cfg)
    print(f"\nData cleaning: {rep}\nTrained on {len(tr)} orders (Apr-Aug), replaying {len(te)} orders from September (scaled x{scale:.1f} to {monthly_cod(cfg):,.0f} COD orders/month)\n")
    t = g.assign(share=g.orders / g.orders.sum()).rename(index=LABEL)
    for c in ["saved", "lost", "cost", "net"]: t[c] = (t[c] * scale).round(0)
    t["orders"] = (t.orders * scale).round(0)
    print(t[["orders", "share", "avg_risk", "actual_rto", "saved", "lost", "cost", "net"]].round(2).to_string())
    print(f"\nPER MONTH ({monthly_cod(cfg):,.0f} COD orders): saved {rs(tot.saved*scale)} | lost {rs(tot.lost*scale)} | discounts+WhatsApp {rs(tot.cost*scale)} | NET {rs(tot.net*scale)}")
    print(f"Hold/cancel reality check: of {real['cancelled']} cancelled, {real['cancelled_that_were_real_rtos']} really were RTOs")
    base = (te.rto.mean() * eco.rto_cost(cfg)) * len(te) * scale
    print(f"Baseline: shipping everything as-is, September RTOs cost about {rs(base)}/month ({te.rto.mean():.1%} RTO).")
    os.makedirs("out", exist_ok=True); out.drop(columns=["phone"]).to_csv("out/decisions_september.csv", index=False)
    print("Wrote out/decisions_september.csv (every order, its action and plain-English reason)")

def cmd_breakeven():
    cfg = load_cfg(); print(f"Cost of one RTO: {rs(eco.rto_cost(cfg))}\n\nOrder value -> margin if delivered -> risk above which SHIPPING loses money")
    for V in [349, 449, 649, 899, 1199, 1799, 2499]:
        print(f"  Rs{V:>5}   margin {rs(eco.margin(V,cfg)):>7}   break-even risk {eco.breakeven_risk(V,cfg):.0%}")
    print("\nMeaning: at the average order, a COD order is still worth shipping until ~70% of such orders would return.")

def cmd_discount():
    cfg = load_cfg(); e = cfg["economics"]
    print("Best prepaid discount (% of order) by risk and basket - maximises expected Rs per order sent the offer\n")
    print("risk\\value   " + "".join(f"Rs{V:<8}" for V in [449, 649, 999, 1499]))
    for p in [0.25, 0.35, 0.45, 0.55]:
        cells = []
        for V in [449, 649, 999, 1499]:
            best = max([x / 100 for x in range(0, 21)], key=lambda f: eco.outcome("nudge", p, V, True, cfg, f * V)["net"])
            cells.append(f"{best:.0%} (Rs{eco.outcome('nudge',p,V,True,cfg,best*V)['net']:.0f})".ljust(11))
        print(f"{p:.0%}         " + "".join(cells))
    V, p = 649, 0.35; R = eco.rto_cost(cfg); q = e["prepaid_rto_rate"]
    print(f"\nWorked example (Rs649 order, 35% risk, 9% = Rs58 off): acceptors would have returned {p*e['nudge_acceptor_risk_factor']:.0%} as COD vs {q:.0%} prepaid -> "
          f"each acceptor saves ~{rs((p*e['nudge_acceptor_risk_factor']-q)*(R+eco.margin(V,cfg)))} in returns+rescued sales, costs Rs58x{1-q:.2f} + gateway {rs(e['prepaid_gateway_fee']*V)}. "
          f"Acceptance at that discount = {eco.accept_rate(58,V,cfg):.0%}.")

def cmd_dashboard():
    from .dashboard import build
    cfg = load_cfg(); m, out, tr, te = split_run(cfg); print("Wrote", build(out), "- open it in your browser")

def cmd_score(order_id):
    cfg = load_cfg(); d, _ = prepare(); m, out, _, _ = split_run(cfg, d)
    r = out[out.order_id == order_id]
    print(r[["order_id", "p", "action", "discount", "reason"]].to_string(index=False) if len(r) else "Order not in the September replay")

def cmd_sensitivity():
    cfg = load_cfg(); d, _ = prepare(); res = []
    for yes in [0.4, 0.6, 0.8]:
        for mult in [0.3, 0.5, 0.8]:
            c = copy.deepcopy(cfg); c["economics"]["confirm_reply_yes_rate"] = yes; c["economics"]["confirmed_rto_multiplier"] = mult
            m, out, _, _ = split_run(c, d); g = out.groupby("action").net.sum() * monthly_cod(c) / len(out)
            res.append((yes, mult, g.get("ship_after_confirmation", 0), out.net.sum() * monthly_cod(c) / len(out)))
    print("How wrong can my assumptions be? (Rs per month, 1,650 COD orders)\nreply-yes-rate  confirmed-RTO-multiplier  confirm-bucket net   total net")
    for r in res: print(f"{r[0]:<15.0%} {r[1]:<24.1f} {r[2]:>12,.0f} {r[3]:>14,.0f}")

def cmd_findings():
    from .findings import run; run()

def main(argv):
    cmd = argv[0] if argv else "help"
    if cmd == "backtest": cmd_backtest()
    elif cmd == "breakeven": cmd_breakeven()
    elif cmd == "discount": cmd_discount()
    elif cmd == "dashboard": cmd_dashboard()
    elif cmd == "sensitivity": cmd_sensitivity()
    elif cmd == "findings": cmd_findings()
    elif cmd == "score": cmd_score(argv[1])
    elif cmd == "whatsapp-demo":
        from .demo import scripted; scripted()
    elif cmd == "chat":
        from .demo import interactive; interactive()
    elif cmd == "all": cmd_backtest(); cmd_dashboard()
    else:
        print("Commands: backtest | dashboard | breakeven | discount | sensitivity | findings | score <order_id> | whatsapp-demo | chat | all")
