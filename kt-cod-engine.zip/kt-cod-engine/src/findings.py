"""Reproduces every number quoted in the memo. python run.py findings"""
import pandas as pd
from .backtest import prepare, split_run, monthly_cod
from .engine import load_cfg
from . import economics as eco

def run():
    d, rep = prepare(); cfg = load_cfg(); R = eco.rto_cost(cfg); m = cfg["economics"]["gross_margin"]
    p = lambda s: f"{s:.1%}"
    print(f"Orders {len(d)}, RTO {p(d.rto.mean())}, avg order value Rs{d.order_value.mean():.0f} (brief says Rs649), RTO cost Rs{R:.1f}")
    print("\n1) Break-even risk at avg order:", f"{eco.breakeven_risk(649,cfg):.0%}", "| margin Rs", round(eco.margin(649, cfg)))
    mdl, out, tr, te = split_run(cfg, d); K = monthly_cod(cfg)
    print("   Naive 'cancel every order above risk X' - REALISED on September (known outcomes), Rs per month at 1,650 COD orders:")
    for x in [0.30, 0.40, 0.50, 0.60]:
        c = out[out.p >= x]; saved = c.rto.sum() * R; lost = ((1 - c.rto) * c.order_value * m).sum()
        print(f"   cancel p>={x:.0%}: cancels {len(c)/len(out):.0%} of orders, {1-c.rto.mean():.0%} of them were genuine; saved {saved*K/len(out):,.0f} lost {lost*K/len(out):,.0f} net {(saved-lost)*K/len(out):,.0f}")
    print("\n2) By address class (RTO):\n", d.groupby("addr_class").rto.agg(["count", "mean"]).round(3).to_string())
    t2 = ["Darbhanga", "Sagar", "Gorakhpur", "Bareilly", "Patna", "Kota", "Madhubani", "Nagaon", "Guwahati", "Lucknow"]
    d["tier2"] = d.city.isin(t2)
    print(d.groupby(["tier2", "addr_class"]).rto.agg(["count", "mean"]).round(3).to_string())
    print("\n3) City RTO:\n", d.groupby("city").rto.agg(["count", "mean"]).sort_values("mean").round(3).to_string())
    pc = d.groupby("pincode").size(); print(f"   Pincodes: {d.pincode.nunique()} distinct in {len(d)} orders; {(pc>=5).sum()} with 5+ orders; {(pc>=10).sum()} with 10+")
    print("\n4) First-time vs repeat:\n", d.groupby("first_time").rto.agg(["count", "mean"]).round(3).to_string())
    print(d.groupby("customer_prior_rto").rto.agg(["count", "mean"]).round(3).to_string())
    print(d.groupby(["utm_source", "first_time"]).rto.mean().unstack().round(3).to_string())
    print("\n5) Basket size:\n", d.groupby(pd.cut(d.order_value, [-1, 700, 1200, 1800, 3000])).rto.agg(["count", "mean"]).round(3).to_string())
    print("\n6) Model on unseen September: calibration")
    from sklearn.metrics import roc_auc_score
    print("   AUC", round(roc_auc_score(out.rto, out.p), 3), "| top 20% riskiest orders hold", p(out.sort_values("p", ascending=False).head(int(len(out)*.2)).rto.sum()/out.rto.sum()), "of all RTOs")
    print(d.groupby("fake_name").rto.agg(["count", "mean"]).round(3).to_string())
    print(d.groupby("courier").rto.agg(["count", "mean"]).round(3).to_string())
    print(d.groupby(d.order_datetime.dt.to_period("M")).rto.mean().round(3).to_string())
