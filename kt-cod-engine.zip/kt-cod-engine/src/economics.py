"""All the money maths. Each function returns rupees. Nothing here uses an LLM."""

def rto_cost(cfg):
    e = cfg["economics"]
    return e["forward_shipping"] + e["return_shipping"] + e["packaging_handling"] + e["damaged_share_of_returns"] * e["product_cost"]

def margin(V, cfg): return cfg["economics"]["gross_margin"] * V

def ev_ship(p, V, cfg):
    """Expected profit of shipping a COD order as-is."""
    return (1 - p) * margin(V, cfg) - p * rto_cost(cfg)

def breakeven_risk(V, cfg):
    """Risk above which shipping loses money: (1-p)*m*V = p*R  ->  p = mV/(mV+R)."""
    m = margin(V, cfg); return m / (m + rto_cost(cfg))

def accept_rate(D, V, cfg):
    e = cfg["economics"]
    return min(e["nudge_accept_cap"], e["nudge_accept_base"] + e["nudge_accept_per_discount"] * D / V)

def discount_rupees(V, p, cfg):
    d = cfg["prepaid_discount"]
    pct = next(t["percent_of_order"] for t in d["tiers"] if p < t["up_to_risk"])
    return round(min(d["max_rupees"], max(d["min_rupees"], pct * V)))

def outcome(action, p, V, first, cfg, D=0):
    """
    Expected result of an action, measured against 'ship everything as-is'.
    Returns dict: saved (RTO cost avoided), lost (margin + future value of genuine orders lost),
    cost (discount, WhatsApp), net = saved - lost - cost.
    """
    e = cfg["economics"]; R = rto_cost(cfg); m = margin(V, cfg)
    fv = e["future_value_first_order"] if first else 0
    if action == "ship":
        return dict(saved=0, lost=0, cost=0, net=0)
    if action == "hold_cancel":
        return dict(saved=p * R, lost=(1 - p) * (m + fv), cost=0, net=p * R - (1 - p) * (m + fv))
    if action == "confirm":
        c, mult = e["confirm_reply_yes_rate"], e["confirmed_rto_multiplier"]
        pc = p * mult
        silent_ships = cfg["whatsapp"]["silent_confirm_orders"] == "ship"
        ps = min(0.95, max(0.0, (p - c * pc) / (1 - c)))      # RTO rate among those who stay silent
        saved = p * R - c * pc * R - (((1 - c) * ps * R) if silent_ships else 0)
        lost = (1 - p) * m - c * (1 - pc) * m
        if silent_ships: lost -= (1 - c) * (1 - ps) * m
        lost = max(lost, 0) + fv * max((1 - p) - c * (1 - pc) - ((1 - c) * (1 - ps) if silent_ships else 0), 0)
        cost = e["whatsapp_cost_per_order"]
        if silent_ships: saved = p * R - (c * pc + (1 - c) * ps) * R
        return dict(saved=saved, lost=lost, cost=cost, net=saved - lost - cost)
    if action == "nudge":
        a = accept_rate(D, V, cfg); q = e["prepaid_rto_rate"]
        p_cod_of_acceptors = p * e["nudge_acceptor_risk_factor"]
        prepaid = (1 - q) * (m - D) - q * R - e["prepaid_gateway_fee"] * V
        gain = a * (prepaid - ev_ship(p_cod_of_acceptors, V, cfg))      # decliners ship as COD (unchanged)
        avoided = a * (p_cod_of_acceptors - q)                          # share of orders that stop being returns
        saved = avoided * (R + m)                                       # return cost avoided + sale rescued
        cost = a * ((1 - q) * D + e["prepaid_gateway_fee"] * V) + e["whatsapp_cost_per_order"]
        return dict(saved=saved, lost=0, cost=cost, net=gain - e["whatsapp_cost_per_order"])
    raise ValueError(action)
