"""Backtest = replay past orders through the engine. Train on earlier months, score the last month."""
import pandas as pd
from sklearn.metrics import roc_auc_score
from .cleaning import load_clean
from .llm import judge
from .model import RiskModel
from .engine import run_engine, load_cfg, LABEL, ACTIONS

SPLIT = "2026-09-01"

def prepare(path="data/orders_sample.csv"):
    d, rep = load_clean(path)
    return d.join(judge(d).drop(columns="order_id")), rep

def split_run(cfg=None, d=None):
    d = prepare()[0] if d is None else d
    cfg = cfg or load_cfg()
    tr, te = d[d.order_datetime < SPLIT], d[d.order_datetime >= SPLIT]
    m = RiskModel().fit(tr)
    return m, run_engine(te, m, cfg), tr, te

def monthly_cod(cfg): return cfg["volume"]["monthly_orders"] * cfg["volume"]["cod_share"]

def summarize(out, cfg):
    """Table per bucket; also realised numbers for ship/cancel where we know the real outcome."""
    from . import economics as eco
    R = eco.rto_cost(cfg); scale = monthly_cod(cfg) / len(out)
    g = out.groupby("action").agg(orders=("p", "size"), avg_risk=("p", "mean"), actual_rto=("rto", "mean"),
                                  saved=("saved", "sum"), lost=("lost", "sum"), cost=("cost", "sum"), net=("net", "sum"))
    g = g.reindex(ACTIONS).fillna(0)
    h = out[out.action == "hold_cancel"]
    real = dict(cancelled=len(h), cancelled_that_were_real_rtos=int(h.rto.sum()),
                realised_saved=float(h.rto.sum() * R),
                realised_lost=float(((1 - h.rto) * h.order_value * cfg["economics"]["gross_margin"]).sum()))
    tot = out[["saved", "lost", "cost", "net"]].sum()
    return g, real, tot, scale
