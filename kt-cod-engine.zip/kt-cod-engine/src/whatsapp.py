"""
WhatsApp confirmation + prepaid-nudge flow (mock).  Pure code: a small state machine.
The LLM is used for exactly one thing here: understanding an unclear free-text reply
(e.g. "kal bhej dena", "address galat hai") - and only after simple keyword rules fail.
Without an API key that fallback just asks the customer to reply 1 or 2.
"""
import re
from dataclasses import dataclass, field
from datetime import datetime, timedelta

MSG = {
 "confirm": {
  "english": "Hi {name}! Your order {oid} ({items}, Rs{value}) is ready to ship to {city}. Pay Rs{value} in cash on delivery.\nReply 1 to CONFIRM or 2 to CANCEL. We ship only after you confirm.",
  "hinglish": "Namaste {name}! Aapka order {oid} ({items}, Rs{value}) {city} ke liye ready hai. Cash on delivery: Rs{value}.\nCONFIRM karne ke liye 1 bhejein, CANCEL ke liye 2. Confirm hone par hi ship karenge."},
 "nudge": {
  "english": "Hi {name}! Your order {oid} (Rs{value}) is ready. Pay online now and get Rs{disc} OFF - pay only Rs{pay}: {link}\nPrefer cash on delivery? Reply 2 and we will ship as COD.",
  "hinglish": "Namaste {name}! Aapka order {oid} (Rs{value}) ready hai. Abhi online pay karein aur Rs{disc} OFF paayein - sirf Rs{pay}: {link}\nCash on delivery chahiye? 2 bhejein, hum COD par hi bhej denge."},
 "nudge_reminder": {"english": "Reminder: pay online for Rs{disc} OFF on order {oid}: {link}  (or reply 2 to ship as COD).", "hinglish": "Yaad dilana: online pay karein, order {oid} par Rs{disc} OFF: {link}  (ya COD ke liye 2 bhejein)."},
 "pay_link": {"english": "Great! Pay Rs{pay} here and we ship today: {link}", "hinglish": "Badhiya! Rs{pay} yahan pay karein, hum aaj hi ship karenge: {link}"},
 "reminder": {
  "english": "Gentle reminder: order {oid} is waiting. Reply 1 to confirm or 2 to cancel.",
  "hinglish": "Yaad dilana tha: order {oid} aapke jawab ka wait kar raha hai. Confirm ke liye 1, cancel ke liye 2."},
 "confirmed": {"english": "Thank you! Order {oid} is confirmed and will ship today.", "hinglish": "Shukriya! Order {oid} confirm ho gaya, aaj hi ship hoga."},
 "paid": {"english": "Payment received. Thank you! Order {oid} ships today.", "hinglish": "Payment mil gaya. Shukriya! Order {oid} aaj hi ship hoga."},
 "cod_ok": {"english": "No problem - order {oid} will ship as cash on delivery.", "hinglish": "Theek hai - order {oid} COD par ship hoga."},
 "cancelled": {"english": "Order {oid} is cancelled. You can reorder anytime at our website.", "hinglish": "Order {oid} cancel ho gaya. Kabhi bhi dobara order kar sakte hain: our website."},
 "unclear": {"english": "Sorry, I didn't get that. Reply 1 to confirm or 2 to cancel.", "hinglish": "Maaf kijiye, samajh nahi aaya. Confirm ke liye 1, cancel ke liye 2 bhejein."},
 "human": {"english": "Thanks! A team member will call you shortly about order {oid}.", "hinglish": "Shukriya! Hamari team aapko order {oid} ke baare mein jaldi call karegi."},
 "timeout_cancel": {"english": "We haven't heard back, so order {oid} is cancelled. Reorder anytime at our website.", "hinglish": "Aapka jawab nahi mila, isliye order {oid} cancel kar diya. Dobara order: our website."},
}
YES = {"1", "yes", "y", "haan", "han", "ha", "ok", "okay", "confirm", "confirmed", "theek", "done", "pay", "paid"}
NO = {"2", "no", "n", "nahi", "nahin", "na", "cancel", "mat bhejo", "nope"}

def classify(text):
    t = re.sub(r"[^\w\s]", "", text.lower()).strip()
    words = set(t.split())
    if t in YES or (words & YES and not words & NO): return "yes"
    if t in NO or (words & NO and not words & YES): return "no"
    return "unclear"

@dataclass
class Conversation:
    order: dict           # order_id, name, items, value, city, state, discount
    flow: str             # "confirm" | "nudge"
    cfg: dict
    state: str = "NEW"    # NEW, WAITING, SHIP, CANCELLED, HUMAN
    outcome: str = ""     # ship_prepaid | ship_cod | ship_confirmed | cancelled | human
    sent_at: datetime = None
    reminded: bool = False
    unclear: int = 0
    log: list = field(default_factory=list)

    def lang(self):
        m = self.cfg["whatsapp"]["language_by_state"]
        return m.get(self.order["state"], m["default"])

    def say(self, key, now, **kw):
        o = self.order
        text = MSG[key][self.lang()].format(name=o["name"].split()[0], oid=o["order_id"], items=o["items"],
                   value=o["value"], city=o["city"], disc=o.get("discount", 0),
                   pay=o["value"] - o.get("discount", 0), link=f"https://pay.example/pay/{o['order_id']}", **kw)
        self.log.append((now, "BOT", text)); return text

    def start(self, now):
        self.sent_at, self.state = now, "WAITING"
        return self.say(self.flow, now)

    def reply(self, text, now):
        self.log.append((now, "CUSTOMER", text))
        if self.state != "WAITING": return None
        intent = classify(text)
        if intent == "yes":
            if self.flow == "nudge":                          # wait for the payment webhook (see pay())
                return self.say("pay_link", now)
            self.state, self.outcome = "SHIP", "ship_confirmed"
            return self.say("confirmed", now)
        if intent == "no":
            if self.flow == "nudge":                          # said no to the discount -> ship as COD, no friction
                self.state, self.outcome = "SHIP", "ship_cod"
                return self.say("cod_ok", now)
            self.state, self.outcome = "CANCELLED", "cancelled"
            return self.say("cancelled", now)
        self.unclear += 1                                    # random reply
        if self.unclear > self.cfg["whatsapp"]["max_unclear_replies"]:
            self.state, self.outcome = "HUMAN", "human"
            return self.say("human", now)
        return self.say("unclear", now)

    def pay(self, now):
        """Payment-gateway webhook says the customer paid."""
        if self.state != "WAITING": return None
        self.state, self.outcome = "SHIP", "ship_prepaid"; return self.say("paid", now)

    def tick(self, now):
        """Call this as time passes (cron every 15 min in real life). Handles reminder + 24h silence."""
        if self.state != "WAITING": return None
        w = self.cfg["whatsapp"]; waited = now - self.sent_at
        if not self.reminded and waited >= timedelta(hours=w["reminder_after_hours"]) and 9 <= now.hour < 21:
            self.reminded = True; return self.say("nudge_reminder" if self.flow == "nudge" else "reminder", now)
        if waited >= timedelta(hours=w["give_up_after_hours"]):
            policy = w["silent_nudge_orders" if self.flow == "nudge" else "silent_confirm_orders"]
            if policy == "ship":
                self.state, self.outcome = "SHIP", "ship_cod"; self.log.append((now, "SYSTEM", "No reply in 24h -> shipping as COD (policy)."))
                return None
            self.state, self.outcome = "CANCELLED", "cancelled"
            return self.say("timeout_cancel", now)
        return None

def render(conv):
    return "\n".join(f"[{t:%d %b %H:%M}] {who:8}: {x}" for t, who, x in conv.log)
