"""The decision engine: risk score + rules file -> one of 4 actions, with a plain-English reason."""
import yaml, pandas as pd
from . import economics as eco

ACTIONS = ["ship_as_is", "ship_after_confirmation", "nudge_to_prepaid", "hold_cancel"]
LABEL = {"ship_as_is": "Ship as-is", "ship_after_confirmation": "Ship after confirmation",
         "nudge_to_prepaid": "Nudge to prepaid", "hold_cancel": "Hold / cancel"}

def load_cfg(path="config/rules.yaml"):
    return yaml.safe_load(open(path))

def decide(p, V, first, prior_rto, cfg, drivers=()):
    th = cfg["thresholds"]; why = "; ".join(drivers) if drivers else "no risk signals"
    risk = f"{p:.0%} chance of return"
    be = eco.breakeven_risk(V, cfg)
    if prior_rto >= cfg["hard_rules"]["hold_if_prior_rtos_at_least"]:
        return "hold_cancel", 0, f"Customer already returned {prior_rto} orders ({risk}). {why}."
    cancel_at = th["hold_cancel_first_time"] if first else th["hold_cancel_repeat"]
    cancel_at = max(cancel_at, be)          # never cancel while shipping still earns money
    if p >= cancel_at:
        return "hold_cancel", 0, f"{risk} - above the {cancel_at:.0%} cancel bar for {'first-time' if first else 'repeat'} customers. {why}."
    if p >= th["confirm_from"]:
        return "ship_after_confirmation", 0, f"{risk}. Ask on WhatsApp before shipping. {why}."
    if p >= th["nudge_from"]:
        if V < th["min_prepaid_nudge_value"]:
            return "ship_as_is", 0, f"{risk}, but order is too small for a prepaid discount to pay off. Shipping. {why}."
        D = eco.discount_rupees(V, p, cfg)
        return "nudge_to_prepaid", D, f"{risk}. Offer Rs{D} off to pay online. {why}."
    return "ship_as_is", 0, f"Only {risk} - ship normally."

def run_engine(d, model, cfg):
    """d must already carry addr_class / fake_name. Returns d with p, action, reason, money columns."""
    d = d.copy(); d["p"] = model.predict(d)
    rows = []
    for r in d.itertuples(index=False):
        row = r._asdict(); p = row["p"]
        drivers = model.reasons(row) if p >= cfg["thresholds"]["nudge_from"] else []
        a, D, why = decide(p, row["order_value"], row["first_time"], row["customer_prior_rto"], cfg, drivers)
        key = {"ship_as_is": "ship", "ship_after_confirmation": "confirm", "nudge_to_prepaid": "nudge", "hold_cancel": "hold_cancel"}[a]
        o = eco.outcome(key, p, row["order_value"], row["first_time"], cfg, D)
        rows.append(dict(action=a, discount=D, reason=why, saved=o["saved"], lost=o["lost"], cost=o["cost"], net=o["net"]))
    return pd.concat([d.reset_index(drop=True), pd.DataFrame(rows)], axis=1)
