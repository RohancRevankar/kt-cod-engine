"""Load orders_sample.csv and fix the data problems we found (all counted in the report)."""
import re
import pandas as pd

def clean_phone(p):
    digits = re.sub(r"\D", "", str(p))
    if len(digits) == 12 and digits.startswith("91"):
        digits = digits[2:]
    return digits

def load_clean(path="data/orders_sample.csv"):
    raw = pd.read_csv(path, dtype={"phone": str})
    rep = {"rows_raw": len(raw)}
    d = raw.drop_duplicates().copy()
    rep["exact_duplicate_rows_removed"] = len(raw) - len(d)
    d["status"] = d["final_status"].str.strip().str.upper()
    rep["status_spelling_variants_fixed"] = int((d["final_status"] != d["status"]).sum())
    rep["still_in_transit_dropped"] = int((d["status"] == "IN_TRANSIT").sum())
    d = d[d["status"].isin(["DELIVERED", "RTO"])].copy()
    d["rto"] = (d["status"] == "RTO").astype(int)
    d["phone"] = d["phone"].map(clean_phone)
    d["phone_valid"] = d["phone"].str.fullmatch(r"[6-9]\d{9}").fillna(False)
    rep["invalid_phone_numbers"] = int((~d["phone_valid"]).sum())
    rep["missing_pincode"] = int(d["pincode"].isna().sum())
    rep["missing_city_filled_from_state"] = int(d["city"].isna().sum())
    top_city = d.dropna(subset=["city"]).groupby("state")["city"].agg(lambda s: s.value_counts().index[0])
    d["city"] = d["city"].fillna(d["state"].map(top_city))
    rep["zero_value_orders"] = int((d["order_value"] <= 0).sum())
    d["order_datetime"] = pd.to_datetime(d["order_datetime"])
    d["date"] = d["order_datetime"].dt.date
    d["first_time"] = (d["customer_prior_orders"] == 0)
    rep["rows_clean"] = len(d)
    return d.reset_index(drop=True), rep
