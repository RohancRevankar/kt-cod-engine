"""Builds out/dashboard.html - one screen, open it in a browser. Numbers are ESTIMATES (outcomes of yesterday's orders aren't known yet)."""
import json
from .engine import LABEL, ACTIONS

HTML = """<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>COD morning brief</title><style>
:root{--bg:#fafaf7;--card:#fff;--ink:#1c1c1a;--mute:#6b6b66;--line:#e4e3dc;--good:#1a7f4b;--bad:#b3261e;--bar:#3b6fd4}
@media(prefers-color-scheme:dark){:root{--bg:#161614;--card:#21211e;--ink:#f0efe8;--mute:#a3a29a;--line:#34342f;--good:#4cc38a;--bad:#ff8a80;--bar:#7aa2f7}}
*{box-sizing:border-box}body{margin:0;background:var(--bg);color:var(--ink);font:16px/1.45 system-ui,sans-serif;padding:20px;max-width:980px;margin-inline:auto}
h1{font-size:20px;margin:0 0 4px}.sub{color:var(--mute);font-size:14px;margin-bottom:16px}
select{font:inherit;padding:6px 10px;border-radius:8px;border:1px solid var(--line);background:var(--card);color:var(--ink)}
.grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(200px,1fr));gap:12px;margin:14px 0}
.card{background:var(--card);border:1px solid var(--line);border-radius:12px;padding:14px}
.k{color:var(--mute);font-size:13px}.v{font-size:28px;font-weight:650}.good{color:var(--good)}.bad{color:var(--bad)}
.row{display:grid;grid-template-columns:170px 1fr 48px;gap:10px;align-items:center;margin:8px 0;font-size:15px}
.bar{height:14px;border-radius:7px;background:var(--bar)}table{width:100%;border-collapse:collapse;font-size:14px}
td,th{padding:6px 4px;border-bottom:1px solid var(--line);text-align:left}td.r,th.r{text-align:right}.note{color:var(--mute);font-size:13px;margin-top:14px}
</style></head><body>
<h1>COD morning brief</h1><div class="sub">Day: <select id="day"></select> &nbsp; Estimates from the risk model, not final outcomes.</div>
<div class="grid" id="kpis"></div>
<div class="card"><div class="k">Orders by decision</div><div id="bars"></div></div>
<div class="card" style="margin-top:12px"><div class="k">What was ordered today and why (highest-risk first)</div><table id="tbl"></table></div>
<div class="note" id="note"></div>
<script>
const DATA=__DATA__, LABEL=__LABEL__, ORDER=__ORDER__;
const rs=n=>(n<0?"-":"")+"\\u20B9"+Math.abs(Math.round(n)).toLocaleString("en-IN");
const sel=document.getElementById("day");
["ALL"].concat(Object.keys(DATA.days)).reverse().forEach(d=>sel.add(new Option(d==="ALL"?"Whole month":d,d)));
sel.value=DATA.latest;
function draw(){const rows=sel.value==="ALL"?Object.values(DATA.days).flat():DATA.days[sel.value];
 const c={},s={saved:0,lost:0,cost:0,net:0};ORDER.forEach(a=>c[a]=0);
 rows.forEach(r=>{c[r.a]++;s.saved+=r.saved;s.lost+=r.lost;s.cost+=r.cost;s.net+=r.net});
 const card=(k,v,cl)=>`<div class="card"><div class="k">${k}</div><div class="v ${cl||""}">${v}</div></div>`;
 document.getElementById("kpis").innerHTML=card("Saved from avoided RTOs",rs(s.saved),"good")+card("Lost from cancelled / unconfirmed orders that may have been genuine",rs(-s.lost),"bad")+card("Discounts + WhatsApp costs",rs(-s.cost),"bad")+card("Net impact",rs(s.net),s.net>=0?"good":"bad");
 const mx=Math.max(1,...Object.values(c));document.getElementById("bars").innerHTML=ORDER.map(a=>`<div class="row"><span>${LABEL[a]}</span><div><div class="bar" style="width:${100*c[a]/mx}%"></div></div><b>${c[a]}</b></div>`).join("");
 document.getElementById("tbl").innerHTML="<tr><th>Order</th><th>Decision</th><th class='r'>Risk</th><th>Why</th></tr>"+rows.filter(r=>r.a!=="ship_as_is").sort((x,y)=>y.p-x.p).slice(0,12).map(r=>`<tr><td>${r.id}</td><td>${LABEL[r.a]}</td><td class="r">${Math.round(r.p*100)}%</td><td>${r.why}</td></tr>`).join("");
 document.getElementById("note").textContent=`${rows.length} COD orders. "Saved" = return costs avoided (+ sales rescued by prepaid). "Lost" = margin on orders we did not ship that would probably have been delivered. Net = saved - lost - discounts - WhatsApp costs. Assumptions: config/rules.yaml.`}
sel.onchange=draw;draw();</script></body></html>"""

def build(out, path="out/dashboard.html"):
    days = {}
    for r in out.itertuples():
        days.setdefault(str(r.date), []).append(dict(id=r.order_id, a=r.action, p=round(r.p, 3), why=r.reason,
            saved=round(r.saved, 1), lost=round(r.lost, 1), cost=round(r.cost, 1), net=round(r.net, 1)))
    data = dict(days=days, latest=max(days))
    html = HTML.replace("__DATA__", json.dumps(data)).replace("__LABEL__", json.dumps(LABEL)).replace("__ORDER__", json.dumps(ACTIONS))
    open(path, "w").write(html); return path
